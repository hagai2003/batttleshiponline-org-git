<?php 
// gamedescription (if not empty) will be in H1 on game page, otherwise gamename will be the H1
if (get_current_page_content("gamedescription")!="")
{
?>  <h3 class="pageName"><?php echo get_current_page_content("gamedescription");?></h3>  <?php
}
else
{
?>  <h3 class="pageName"><?php echo get_current_page_content("gamename");?></h3>  <?php
}
?>
<div class="bodyText">
<p style="margin-top:14px;">
<?php echo get_current_page_content("gameinstructions");?>
</p>


<?php 
$script=get_current_page_content("gamescript");
if (strpos($script,"script") || strpos($script,"object") || strpos($script,"embed")) 
{ 
	// if "gameinstruction" has "<script" in it we assume novelgames (or other embedded game) 
	?>
	<p style="margin-left:0px;margin-top:20px;border:<?php echo get_current_page_content("objectborder");?>px solid #<?php echo $GLOBALS['game_object_border_color'];?>;">
	<?php
	echo $script;
}
else
{
?>
<p style="margin-left:0px;margin-top:20px;border:<?php echo get_current_page_content("objectborder");?>px solid #<?php echo $GLOBALS['game_object_border_color'];?>;width:<?php echo get_current_page_content("objectwidth");?>px;height:<?php echo get_current_page_content("objectheight");?>px;">

<object width="<?php echo get_current_page_content("objectwidth");?>px" height="<?php echo get_current_page_content("objectheight");?>px"><param name="salign" value="<?php echo get_current_page_content("objectalign");?>"/><param name="align" value="<?php echo get_current_page_content("objectalign");?>"/><param name="movie" value="games/<?php echo get_game_swf_name();?>.swf"><param name="allowScriptAccess" value="always"><param name="allowFullScreen" value="true"><param name="loop" value="false"><param name="menu" value="false"><param name="quality" value="high"><param name="wmode" value="window"><embed src="games/<?php echo get_game_swf_name();?>.swf" type="application/x-shockwave-flash" width="<?php echo get_current_page_content("objectwidth");?>px" align="<?php echo get_current_page_content("objectalign");?>" salign="<?php echo get_current_page_content("objectalign");?>" height="<?php echo get_current_page_content("objectheight");?>px" allowscriptaccess="always" allowfullscreen="true" loop="false" menu="false" quality="high" wmode="window" ></embed></object>
<?php
}
?>
</p>

<!-- highscores start -->
<?php if ($GLOBALS['digsolitaire_highscores'] && get_current_page_content("section2")!="") 
{ 	// showing high-scores ?>
<br/>

<div style="text-align:left;" name="highscoreDiv" id="highscoreDiv" >
<?php 
	$novel_gameid=get_current_page_content("section2");
	$duration="thisweek";
	printHighScores($novel_gameid, $duration);
?>
</div>
<?php
}
?>
<!-- highscores end -->

<br/>

<div style="text-align:left;">
<table  border="0" cellspacing="0" cellpadding="0" style="table-layout:fixed;border:1px solid white;">
<colgroup>
	<?php 
	for ($i=1; $i<=$GLOBALS['games_menu_games_per_line']; $i++)
	{
		echo '<col width="'."20".'px" style="width:'."20px".'" />';
		echo '<col width="'.$GLOBALS['game_table_column'.$i].'px" style="width:'.$GLOBALS['game_table_column'.$i].'px;" />';

	}
	?>
</colgroup>
<tr><td colspan="<?php echo 2*$GLOBALS['games_menu_games_per_line'];?>" style="padding-top:8px;padding-bottom:8px;"><span class="sidebarOrange">&nbsp;<?php echo $GLOBALS['games_div_h3_header'];?>:</span></td></tr>
<tr>
<?php
$where_clause="where type='game'";
template_html_menu($where_clause,
		'<td>&nbsp;</td><td class="moregamestd"><a class="orangeLinkTurnsWhite" href="',
		'">',
		'</a></td>',
		$GLOBALS['games_menu_games_max_games'],
		$GLOBALS['games_menu_games_per_line'],
		'</tr><tr>',
		'<td>&nbsp;</td>'."\n",
		false,
		true);
?>
</tr>
<tr><td colspan="<?php echo 2*$GLOBALS['games_menu_games_per_line'];?>" style="line-height:8px;">&nbsp;</td></tr>
</table>
</div>
<br/><br/>

<?php adsystem("gamepage_728x90"); ?>

<br/><br/><br/>

<?php 
$section1 = get_current_page_content("section1");
if ($section1 != "")
{
	echo '<div class="bodyText">';
	echo $section1;
	echo '</div>';
}
?>

</div>