<?php echo get_current_page_content("section1");?>
<?php echo get_current_page_content("section2");?>

<br/>

<?php adsystem("gamepage_728x90"); ?>

<br/><br/>