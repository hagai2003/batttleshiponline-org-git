<div id="menudiv" style="margin-top:6px;">
<?php
template_html_menu("where intoolbar>'0'",'<a href="','">','</a> | ',$GLOBALS['main_menu_number_of_games'],0,"","",$GLOBALS['main_menu_show_more_articles_page_if_relevant']);
?>
</div>
<div id="maincontainer">
<hr class="hr1" noshade="noshade" />
<div id="contentwrapper">
<div id="contentcolumn">
<div class="innertube">
<div style="line-height:20px;">&nbsp;</div>
<?php adsystem("allpage_responsive");     ?>
<div style="line-height:20px;">&nbsp;</div>