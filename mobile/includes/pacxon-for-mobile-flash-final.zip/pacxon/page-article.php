<div align="left" style="margin:0 auto;width:90%;">
<?php echo get_current_page_content("section1");?>
<?php echo get_current_page_content("section2");?>
</div>