<?php echo get_current_page_content("section1");?>
<?php echo get_current_page_content("section2");?>