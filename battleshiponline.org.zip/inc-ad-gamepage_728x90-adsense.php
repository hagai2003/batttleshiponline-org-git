<script type="text/javascript"><!--
google_ad_client = "ca-pub-1609789099200669";
/* GalagaGame 728x90 */
google_ad_slot = "1142161042";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>